<?php 

function doneTodos($con){
  $doneTodos = mysqli_query($con, "SELECT * FROM todo WHERE todo.done=1 ORDER BY `date` ASC");
  $num = 1;
  while( $row = mysqli_fetch_array($doneTodos) ):
    echo '<tr>';
      echo '<th scope="row">'.$num.'</th>';
      echo '<td>'.$row["todo"].'</td>';
      echo '<td>'.date('m/d/Y', $row["date"]).'</td>';
      echo '<td>'; 
        echo '<a href="?id='.$row["id"].'&status=return">Return</a>';
        echo ' <a class="text-danger mx-2 d-inline-block" href="?id='.$row["id"].'&status=delete">Delete</a>';
      echo '</td>';
    echo '</tr>';
    $num++;
  endwhile;
}

function todos($con) {
  $todos = mysqli_query($con, "SELECT * FROM todo WHERE todo.done=0 ORDER BY `date` ASC");
  $num = 1;
  while( $row = mysqli_fetch_array($todos) ):
    echo '<tr>';
      echo '<th scope="row">'.$num.'</th>';
      echo '<td>'.$row["todo"].'</td>';
      echo '<td>'.date('m/d/Y', $row["date"]).'</td>';
      echo '<td>'; 
        echo ($row["done"]==0) ? '<a href="?id='.$row["id"].'&status=done">Done</a>' : '';
        echo ' <a class="text-danger mx-2 d-inline-block" href="?id='.$row["id"].'&status=delete">Delete</a>';
      echo '</td>';
    echo '</tr>';
    $num++;
  endwhile;
}
  