<?php

define('DATABASE', 'php_todo');
define('USERNAME', 'root');
define('PASSWORD', '');