<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
  <title>TODO Installer</title>
</head>
<body>
  <div class="col-md-6 mx-auto mt-5 rounded p-4">
    <p>
    Hello everyone. <br/>
    This is a simple todo list in php/mysql.

    <p>
    1. First of all create a database and user.<br/>
    2. Next go to config.php file and insert them. <br/>
    3. Next go to youraddress/install.php address to create table.<br/><br/>
    Now everything is ok. go home and insert your tasks and do them.
    </p>

    <br/>
    <h5 class="mb-0">Features:</h5>
    <ul class="p-3 mb-0">
      <li>U can add new todo (v1)</li>
      <li>Latest todos saves in database (v1)</li>
      <li>U can change todo status (v1)</li>
      <li>U can Delete todo (v1)</li>
    </ul>
  </div>
  
</body>
</html>

